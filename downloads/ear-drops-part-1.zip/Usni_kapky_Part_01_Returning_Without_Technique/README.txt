Ušní kapky – Návrat bez techniky
DÍL 01 / Part 01

Krátké zvukové momenty pro běžný den.
Bez techniky, bez vedení a bez cíle.

Můžeš si je pustit kdykoliv – nebo vůbec.

---

Ear Drops – Returning Without Technique
Part 01

Short audio moments for everyday use.
Without technique, without guidance, and without a goal.

You can play them anytime – or not at all.
